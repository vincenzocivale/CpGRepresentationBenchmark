from __future__ import annotations

from pathlib import Path

import h5py
import numpy as np


class RepresentationCoverageError(ValueError):
    pass


def validate_canonical_h5(path: Path) -> tuple[np.ndarray, int]:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    with h5py.File(path, "r") as handle:
        if "cpg_idx" not in handle or "embedding" not in handle:
            raise RepresentationCoverageError(f"{path} must contain /cpg_idx and /embedding")
        cpg_ids = np.asarray(handle["cpg_idx"][:], dtype=np.int64)
        embedding = handle["embedding"]
        if embedding.ndim != 2 or embedding.shape[0] != len(cpg_ids):
            raise RepresentationCoverageError(f"invalid embedding shape in {path}: {embedding.shape}")
        dim = int(embedding.shape[1])
    if len(cpg_ids) != len(np.unique(cpg_ids)):
        raise RepresentationCoverageError(f"{path} contains duplicate cpg_idx values")
    return cpg_ids, dim


class HDF5RepresentationStore:
    """Canonical CpG representation store mapped into methylation-matrix column order."""

    def __init__(self, path: Path, matrix_cpg_ids: np.ndarray):
        self.path = Path(path)
        store_ids, self._dim = validate_canonical_h5(self.path)
        order = np.argsort(store_ids)
        sorted_ids = store_ids[order]
        matrix_cpg_ids = np.asarray(matrix_cpg_ids, dtype=np.int64)
        pos = np.searchsorted(sorted_ids, matrix_cpg_ids)
        present = pos < len(sorted_ids)
        present[present] &= sorted_ids[pos[present]] == matrix_cpg_ids[present]
        self.coverage_mask = present
        self._rows = np.full(len(matrix_cpg_ids), -1, dtype=np.int64)
        self._rows[present] = order[pos[present]]
        self._handle: h5py.File | None = None

    @property
    def dim(self) -> int:
        return self._dim

    def _embedding(self):
        if self._handle is None:
            self._handle = h5py.File(self.path, "r")
        return self._handle["embedding"]

    def get_by_matrix_columns(self, matrix_columns: np.ndarray) -> np.ndarray:
        matrix_columns = np.asarray(matrix_columns, dtype=np.int64)
        rows = self._rows[matrix_columns]
        if (rows < 0).any():
            bad = matrix_columns[rows < 0][:10].tolist()
            raise RepresentationCoverageError(f"representation is missing requested matrix columns: {bad}")
        order = np.argsort(rows)
        values = np.asarray(self._embedding()[rows[order]], dtype=np.float32)
        inverse = np.empty_like(order)
        inverse[order] = np.arange(len(order))
        return values[inverse]

    def close(self) -> None:
        if self._handle is not None:
            self._handle.close()
            self._handle = None
