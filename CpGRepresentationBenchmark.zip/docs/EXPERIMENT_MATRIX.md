# Experiment matrix

## Phase 1 — deploy the masking benchmark

| Arm | Representation source | Acquisition mode | Status |
|---|---|---|---|
| Functional | ENCODE/reference functional-locus encoder recovered from MehylPredictor | existing HDF5 | ready |
| Functional-online | same encoder, encoded lazily by CpG ID | online | ready |
| NTv3-pre | sequence genomic FM locus embedding | existing HDF5 | ready |

Every arm runs the same persistent CpG protocol, patient split, model and five masking fractions in both `seen` and `unseen_locus` views.

## Phase 2 — representation adapters

Add canonical extraction for CpGPT, MethylGPT, DNAmBERT, MethylProphet's locus representation and additional genomic FMs. Each adapter should export one patient-agnostic vector per CpG and record checkpoint/layer/pooling/window/genome-build provenance.

For each new encoder, first run the representation-controlled benchmark. Only after that should its native masked-prediction head be evaluated as a separate complete-method comparison.

## Phase 3 — strict fairness controls

- fixed 256-D train-locus PCA/IncrementalPCA for every raw representation;
- multiple random seeds for downstream reconstruction training;
- an explicitly named common-vocabulary protocol if a model cannot cover the full dataset CpG universe;
- audit/removal of any methylation-derived functional annotation tracks from the primary functional arm.

## Deferred by current scope

Downstream methylation tasks and the biological experiment are intentionally not implemented in V1. They should use the same persistent representation stores and CpG protocol machinery rather than introducing a second feature pipeline.
