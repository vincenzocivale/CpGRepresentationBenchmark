# Data contract

## Methylation matrix

Canonical HDF5:

- `/beta`: float matrix `[n_samples, n_cpg]`, NaN allowed;
- `/cpg_idx`: unique int64 `[n_cpg]`;
- `/sample_name`: `[n_samples]` strings/bytes.

All patient splits are case-disjoint.

## Shared CpG protocol

The CpG split is **dataset-defined, not representation-defined**. The first run creates the file configured by `experiment.locus_split.protocol_path`; every subsequent representation reuses the same canonical train/held-out CpG IDs. A representation that cannot cover those loci fails explicitly.

Do not silently take a different per-representation intersection. If a future model has restricted vocabulary, deliberately build a named common-universe protocol and use that same protocol for every arm in that comparison.

## CpG representation store

Cached representations — functional annotations, genomic FMs or published methylation-model encoders — resolve to:

- `/cpg_idx`: unique int64 `[n_loci]`;
- `/embedding`: float16/float32 `[n_loci, d]`.

The store may contain extra loci, but it must cover every locus required by the selected benchmark protocol.

## Representation modes

`representation.mode` supports four modes:

- `precomputed`: use an existing canonical HDF5 cache;
- `generate_if_missing`: invoke `generator.command` at run start only when the cache is absent;
- `regenerate`: force a cache rebuild before the run;
- `online`: call a Python encoder provider lazily from requested canonical CpG IDs, with an optional bounded LRU cache.

Generation commands can use `{output}`, `{registry}`, `{repo_root}`, `{run_dir}`. Cached materialization is recommended for expensive FMs because it is faster and gives an auditable immutable feature artifact.

`online` is genuine runtime/on-the-fly encoding. Its provider factory must implement an object with `dim` and `encode(cpg_ids)`. Because these providers commonly own GPU model state, online mode requires `training.num_workers=0` and `evaluation.num_workers=0`.

The functional annotation encoder recovered from MehylPredictor already has an online factory:

```yaml
representation:
  mode: online
  provider:
    factory: cpg_repr_benchmark.representations.functional_provider:build_functional_online_provider
```

See `configs/experiments/masking/functional_online.yaml`.

## Model sample

For patient `s`:

- observed CpG embeddings `[K, d]`;
- observed methylation residuals `[K]`;
- target CpG embeddings `[Q, d]`;
- target prior logits `[Q]`;
- hidden target beta `[Q]`.

The target beta values never enter the patient encoder.
