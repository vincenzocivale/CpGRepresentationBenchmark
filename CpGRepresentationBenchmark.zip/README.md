# CpGRepresentationBenchmark

A controlled benchmark for one broad question: **what is the most useful patient-agnostic representation of a CpG locus for methylation modeling?**

The project grows out of the observation in `MehylPredictor` that a CpG representation derived from ENCODE/reference functional annotations can outperform a sequence-only NTv3-pre locus embedding. The scope here is deliberately broader than RNA→methylation prediction: compare functional annotation representations against representations extracted from approaches such as CpGPT, MethylGPT, DNAmBERT, MethylProphet and genomic foundation models.

## Implemented benchmark: masked methylome reconstruction

V1 implements the requested first benchmark only. Two views are first-class:

1. `seen`: masked CpGs belong to the train-locus universe;
2. `unseen_locus`: targets are a disjoint CpG split that never appears as training context or a training target.

For `unseen_locus`, even the prior is leakage-safe: held-out CpG methylation values are never read when the prior is fitted. Held-out loci receive one global prior estimated only from train patients × train loci.

Default masking sweep: **15%, 30%, 50%, 70%, 90%**.

## Primary scientific comparison

The main benchmark is **representation-controlled**. The reconstruction network, patient split, persistent CpG split, masking schedule, optimizer and training budget are fixed; only the CpG representation changes. This is the comparison that can support a claim about representation quality.

Native CpGPT/MethylGPT/etc. masked inference belongs in a secondary complete-method table, because there the representation and prediction architecture both change. The previous `MethylomeReconstruction` project remains useful as a source for those wrappers when that track is added.

The fixed downstream model is intentionally simple:

```text
observed locus representation + observed methylation residual
        -> tokenization
        -> DeepSets patient encoder
        -> patient embedding

target locus representation + patient embedding
        -> residual decoder
        -> sigmoid(target prior + delta)
```

A shared learned adapter maps every raw representation to the same latent width. Before a final paper claim, add the train-locus PCA/IncrementalPCA capacity control described in `docs/BENCHMARK_DESIGN.md` so raw input dimensionality cannot explain the result.

## Four representation modes

Cached representations use one canonical contract:

```text
/cpg_idx    int64 [N]
/embedding  float16/float32 [N, D]
```

The pipeline supports:

- `precomputed` — reuse an existing feature store;
- `generate_if_missing` — build it automatically once when absent, then cache it;
- `regenerate` — force a full rebuild;
- `online` — true runtime/on-the-fly encoding through a Python provider.

The first deployment can therefore use the functional and NTv3-pre embeddings you already have. Later genomic/methylation FM adapters only need to implement this boundary; training code remains unchanged.

## Shared CpG protocol

The train/held-out CpG split is persisted under `data/protocols/` and reused by every representation. It is created from the dataset scope, **not** from each encoder's coverage. If one representation cannot encode a required locus, the run fails rather than silently receiving a different/easier test set.

This is essential for a fair comparison.

## Setup

```bash
python -m pip install -e ".[dev]"
pytest -q
```

## First deployment with existing features

Place or symlink your stores:

```bash
mkdir -p data/features
ln -s /path/to/functional_annotations.h5 data/features/functional_annotations.h5
ln -s /path/to/ntv3_pre.h5 data/features/ntv3_pre.h5
```

Validate them:

```bash
python scripts/validate_feature_store.py \
  --store data/features/functional_annotations.h5 \
  --methylation-h5 /path/to/tcga_array_official_full.h5
```

Run the two initial controlled arms:

```bash
python scripts/run_masking_benchmark.py \
  --config configs/experiments/masking/functional_precomputed.yaml \
  --mode all

python scripts/run_masking_benchmark.py \
  --config configs/experiments/masking/ntv3_precomputed.yaml \
  --mode all
```

Every run prints `RUN_DIR=...` and writes `experiment.json`, checkpoints, per-view/per-mask `metrics.json`, and an aggregate `summary.json`.

Aggregate all completed runs:

```bash
python scripts/summarize_runs.py \
  --outputs outputs \
  --csv outputs/masking_summary.csv
```

## Functional representation: build or encode online

The repo recovers the functional-locus encoding path already used in the existing project: sparse functional tracks + dense locus features -> 256-D patient-agnostic embedding.

Materialize it once:

```bash
python scripts/build_functional_embeddings.py \
  --checkpoint /path/to/MehylPredictor/checkpoints/best.pt \
  --array-cpg-map /path/to/array_cpg_map.parquet \
  --locus-store /path/to/derived/locus_features_v1 \
  --methylpredictor-root /path/to/MehylPredictor \
  --output data/features/functional_annotations.h5
```

Or edit `functional_generate_if_missing.yaml` to let the run build the cache automatically.

For true on-the-fly generation, edit the paths in `functional_online.yaml` and run it directly. Online mode requires `num_workers: 0` because the encoder owns GPU/model state in the main process.

## Repository map

```text
configs/experiments/masking/   executable experiment definitions
configs/representations/       templates for future encoders
data/protocols/                 persistent shared CpG protocols (generated, gitignored)
docs/                          benchmark protocol, leakage rules, extension guide
scripts/                       runner, feature builder, validator, result aggregator
src/cpg_repr_benchmark/data/   patient/locus splits and masking datasets
src/cpg_repr_benchmark/representations/
                               cached + online representation interfaces
src/cpg_repr_benchmark/models/ fixed reconstruction architecture
src/cpg_repr_benchmark/training/
                               leakage-safe priors and training engine
src/cpg_repr_benchmark/evaluation/ metrics
src/cpg_repr_benchmark/experiments/ run-directory/JSON bookkeeping
tests/                          synthetic invariants, no external data required
```

## What is intentionally not implemented yet

The repo is ready for additional representations, but V1 does **not** yet contain extraction adapters/checkpoints for CpGPT, MethylGPT, DNAmBERT or every other literature model, nor downstream classification/biological tasks. The first purpose is to deploy and validate the masking protocol using the already-saved functional and NTv3-pre stores, then add those encoders one by one without changing the benchmark core.

See `docs/ADDING_REPRESENTATIONS.md`, `docs/BENCHMARK_DESIGN.md`, and `docs/OUTPUT_SCHEMA.md` before adding new arms.
